#options(expressions=2000)
#.First.lib <- function(lib, pkg){
#library.dynam("clusterSim", pkg, lib)
#} 
