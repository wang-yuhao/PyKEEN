#.Last.lib <- function(libpath){library.dynam.unload("clusterSim", libpath)}
#.onUnload <- function(libpath){library.dynam.unload("clusterSim", libpath)} 
