library(testthat)
test_check("clusterSim")