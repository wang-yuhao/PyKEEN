# -*- coding: utf-8 -*-

"""PyKEEN's command line interface."""

from .cli import main

if __name__ == '__main__':
    main()
