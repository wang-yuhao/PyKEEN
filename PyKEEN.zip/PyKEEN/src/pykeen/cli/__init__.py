# -*- coding: utf-8 -*-

"""PyKEEN's command line interface."""

from .cli import main  # noqa: 401
