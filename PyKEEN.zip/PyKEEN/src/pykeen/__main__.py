# -*- coding: utf-8 -*-

"""Command line interface for PyKEEN."""

from pykeen.cli import main

if __name__ == '__main__':
    main()
