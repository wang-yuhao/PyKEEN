Summarize all Experiments
=========================
Here, we describe how to summarize all experiments into a single csv-file.
To summarize the results of all experiments, please provide the path to parent directory containing all the experiments
as sub-directories, and the path to the output file:

.. code-block:: python

    pykeen-summarize -d /path/to/experiments/directory -o /path/to/output/file.csv
